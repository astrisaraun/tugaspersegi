
rootProject.name = "tugaspersegi"

